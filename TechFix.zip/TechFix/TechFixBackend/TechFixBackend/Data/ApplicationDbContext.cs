﻿using Microsoft.EntityFrameworkCore;
using Techfix.Model;
using TechFixBackend.Model;

namespace TechFixBackend.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions options) : base(options)
        {
            
        }

        public DbSet<Staff> Staffs { get; set; }

        public DbSet<Order> Orders { get; set; }

        public DbSet<Inventory> Inventorys { get; set; } 

        public DbSet<Supplier> Suppliers { get; set; }

        public DbSet<Quotation> Quotations { get; set; }
    }
}
