﻿namespace Techfix.Model
{
    public class Quotation
    {
        public int Id { get; set; }
        public string SupplierName { get; set; }
        public string Items { get; set; }

    }
}