﻿using System.ComponentModel.DataAnnotations;

namespace TechFixBackend.Model
{
    public class Inventory
    {
        [Key]
        public int ItemId { get; set; } // Unique ID for the item
        public string ItemName { get; set; } // Name of the item
        public int SupplierId { get; set; } // Supplier ID
        public string SupplierName { get; set; } // Name of the supplier
        public int Quantity { get; set; } // Quantity available
        public decimal Price { get; set; } // Price per unit
        public string Description { get; set; } // Description of the item
        public string ImageUrl { get; set; } // Image URL for the item
        
    }
}
