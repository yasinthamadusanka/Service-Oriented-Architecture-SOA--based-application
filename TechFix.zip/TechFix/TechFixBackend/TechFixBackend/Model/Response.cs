﻿using TechFixBackend.Model;

namespace Techfix.Model
{
    public class Response
    {
        public int Statuscode { get; set; }
        public string StatusMessage { get; set; }
        public List<Order> Data { get; internal set; }

        public List<Inventory> List { get; internal set; }

        public List<Supplier> Suppliers {  get; internal set; }  

        public List<Quotation> Quotations { get; internal set; }
    }
}
