﻿namespace Techfix.Model
{
    public class StaffLogin
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
