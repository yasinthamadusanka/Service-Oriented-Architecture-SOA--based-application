﻿using Microsoft.Data.SqlClient;
using Techfix.Utili;
using TechFixBackend.Model;

namespace Techfix.Model
{
    public class Dal
    {
        public string HashPassword(string plainPassword)
        {
            return BCrypt.Net.BCrypt.HashPassword(plainPassword);
        }

        public bool VerifyPassword(string enteredPassword, string storedHash)
        {
            return BCrypt.Net.BCrypt.Verify(enteredPassword, storedHash);
        }

        public Response AddStaff(Staff staff, SqlConnection connection)
        {
            Response response = new Response();
            DBConnection dbc = new DBConnection();

            try
            {
                string hashedPassword = HashPassword(staff.Password);

                SqlCommand checkEmailCmd = new SqlCommand("SELECT COUNT(*) FROM Staffs WHERE Email = @Email", dbc.GetConn());
                checkEmailCmd.Parameters.AddWithValue("@Email", staff.Email);
                dbc.ConOpen();
                int emailExists = (int)checkEmailCmd.ExecuteScalar();
                dbc.ConClose();

                if (emailExists > 0)
                {
                    response.Statuscode = 400;
                    response.StatusMessage = "Email already exists.";
                    return response;
                }

                SqlCommand cmd = new SqlCommand("Insert Into Staffs(Name,Email,Password,cPassword)Values(@Name,@Email,@Password,@cPassword)", dbc.GetConn());

                cmd.Parameters.AddWithValue("@Name", staff.Name);
                cmd.Parameters.AddWithValue("@Email", staff.Email);
                cmd.Parameters.AddWithValue("@Password", hashedPassword);
                cmd.Parameters.AddWithValue("@cPassword", hashedPassword);


                dbc.ConOpen();
                int rowsAffected = cmd.ExecuteNonQuery();
                dbc.ConClose();
                if (rowsAffected > 0)
                {
                    response.Statuscode = 200;
                    response.StatusMessage = "Staff Added Successfully";
                }
                else
                {
                    response.Statuscode = 400;
                    response.StatusMessage = "Staff Addition Failed";
                }
            }
            catch (Exception ex)
            {
                response.Statuscode = 500;
                response.StatusMessage = $"Error: {ex.Message}";
            }

            return response;
        }

        public Response StaffLogin(StaffLogin staffLogin, SqlConnection connection)
        {
            Response response = new Response();

            try
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM Staffs WHERE Email=@Email", connection);
                cmd.Parameters.AddWithValue("@Email", staffLogin.Email);

                if (connection.State == System.Data.ConnectionState.Closed)
                {
                    connection.Open();
                }

                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    reader.Read();
                    string storedHash = reader["Password"].ToString();  // Retrieve stored hash

                    // Verify the entered password against the stored hash
                    if (VerifyPassword(staffLogin.Password, storedHash))
                    {
                        response.Statuscode = 200;
                        response.StatusMessage = "Login Successful";
                    }
                    else
                    {
                        response.Statuscode = 400;
                        response.StatusMessage = "Invalid Credentials";
                    }
                }
                else
                {
                    response.Statuscode = 400;
                    response.StatusMessage = "Invalid Credentials";
                }
            }
            catch (Exception ex)
            {
                response.Statuscode = 500;
                response.StatusMessage = $"Server error: {ex.Message}";
            }
            finally
            {
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();
                }
            }

            return response;
        }

        public Response AddOrder(Order order, SqlConnection connection)
        {
            Response response = new Response();
            DBConnection dbc = new DBConnection();

            try
            {
                SqlCommand cmd = new SqlCommand("Insert Into Orders (SupplierName,ItemName,Quantity, Price, OrderDate, Status, ImageUrl) Values (@SupplierName,@ItemName, @Quantity, @Price, @OrderDate, @Status, @ImageUrl)", dbc.GetConn());

                cmd.Parameters.AddWithValue("@SupplierName", order.SupplierName);
                cmd.Parameters.AddWithValue("@ItemName", order.ItemName);
                cmd.Parameters.AddWithValue("@Quantity", order.Quantity);
                cmd.Parameters.AddWithValue("@Price", order.Price);
                cmd.Parameters.AddWithValue("@OrderDate", order.OrderDate);
                cmd.Parameters.AddWithValue("@Status", order.Status);
                cmd.Parameters.AddWithValue("@ImageUrl", order.ImageUrl);

                dbc.ConOpen();
                int rowsAffected = cmd.ExecuteNonQuery();
                dbc.ConClose();
                if (rowsAffected > 0)
                {
                    response.Statuscode = 200;
                    response.StatusMessage = "Order Placed Successfully";
                }
                else
                {
                    response.Statuscode = 400;
                    response.StatusMessage = "Failed to Place Order";
                }
            }
            catch (Exception ex)
            {
                response.Statuscode = 500;
                response.StatusMessage = $"Error: {ex.Message}";
            }

            return response;
        }

        public Response ViewOrders(SqlConnection connection)
        {
            Response response = new Response();
            DBConnection dbc = new DBConnection();

            try
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM Orders", dbc.GetConn());
                dbc.ConOpen();
                SqlDataReader reader = cmd.ExecuteReader();

                List<Order> orders = new List<Order>();

                while (reader.Read())
                {
                    Order order = new Order()
                    {
                        OrderId = Convert.ToInt32(reader["OrderId"]),
                        SupplierName = reader["SupplierName"].ToString(),
                        ItemName = reader["ItemName"].ToString(),
                        Quantity = Convert.ToInt32(reader["Quantity"]),
                        Price = Convert.ToDecimal(reader["Price"]),
                        OrderDate = Convert.ToDateTime(reader["OrderDate"]),
                        Status = reader["Status"].ToString(),
                        ImageUrl = reader["ImageUrl"].ToString()
                    };
                    orders.Add(order);
                }

                dbc.ConClose();
                response.Statuscode = 200;
                response.StatusMessage = "Orders Retrieved Successfully";
                response.Data = orders;
            }
            catch (Exception ex)
            {
                response.Statuscode = 500;
                response.StatusMessage = $"Error: {ex.Message}";
            }

            return response;
        }

        public Response AddInventoryItem(Inventory item, SqlConnection connection)
        {
            Response response = new Response();
            DBConnection dbc = new DBConnection();

            try
            {
                SqlCommand cmd = new SqlCommand("INSERT INTO Inventorys(ItemName, Quantity, Price, SupplierId, SupplierName, Description, ImageUrl) VALUES (@ItemName, @Quantity, @Price, @SupplierId, @SupplierName, @Description, @ImageUrl)", dbc.GetConn());
                cmd.Parameters.AddWithValue("@ItemName", item.ItemName);
                cmd.Parameters.AddWithValue("@Quantity", item.Quantity);
                cmd.Parameters.AddWithValue("@Price", item.Price);
                cmd.Parameters.AddWithValue("@SupplierId", item.SupplierId);
                cmd.Parameters.AddWithValue("@SupplierName", item.SupplierName);
                cmd.Parameters.AddWithValue("@Description", item.Description);
                cmd.Parameters.AddWithValue("@ImageUrl", item.ImageUrl);

                dbc.ConOpen();
                int rowsAffected = cmd.ExecuteNonQuery();
                dbc.ConClose();

                if (rowsAffected > 0)
                {
                    response.Statuscode = 200;
                    response.StatusMessage = "Item added successfully.";
                }
                else
                {
                    response.Statuscode = 400;
                    response.StatusMessage = "Failed to add item.";
                }
            }
            catch (Exception ex)
            {
                response.Statuscode = 500;
                response.StatusMessage = $"Error: {ex.Message}";
            }

            return response;
        }

        public Response ViewInventory(SqlConnection connection)
        {
            Response response = new Response();
            try
            {
                List<Inventory> items = new List<Inventory>();
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM Inventorys", connection))
                {
                    connection.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            items.Add(new Inventory
                            {
                                ItemId = Convert.ToInt32(reader["ItemId"]),
                                ItemName = reader["ItemName"].ToString(),
                                Quantity = Convert.ToInt32(reader["Quantity"]),
                                Price = Convert.ToDecimal(reader["Price"]),
                                SupplierId = Convert.ToInt32(reader["SupplierId"]),
                                SupplierName = reader["SupplierName"].ToString(),
                                Description = reader["Description"].ToString(),
                                ImageUrl = reader["ImageUrl"].ToString()
                            });
                        }
                    }
                    connection.Close();
                }

                response.Statuscode = 200;
                response.StatusMessage = "Inventory retrieved successfully.";
                response.List = items;
            }
            catch (Exception ex)
            {
                response.Statuscode = 500;
                response.StatusMessage = $"Error: {ex.Message}";
            }
            return response;
        }

        public Response UpdateInventoryItem(Inventory item, SqlConnection connection)
        {
            Response response = new Response();
            DBConnection dbc = new DBConnection();

            try
            {
                SqlCommand cmd = new SqlCommand("UPDATE Inventorys SET ItemName = @ItemName, Quantity = @Quantity, Price = @Price,SupplierId = @SupplierId, SupplierName = @SupplierName, Description = @Description, ImageUrl = @ImageUrl WHERE ItemId = @ItemId", dbc.GetConn());
                cmd.Parameters.AddWithValue("ItemId", item.ItemId);
                cmd.Parameters.AddWithValue("@ItemName", item.ItemName);
                cmd.Parameters.AddWithValue("@Quantity", item.Quantity);
                cmd.Parameters.AddWithValue("@Price", item.Price);
                cmd.Parameters.AddWithValue("@SupplierId", item.SupplierId);
                cmd.Parameters.AddWithValue("@SupplierName", item.SupplierName);
                cmd.Parameters.AddWithValue("@Description", item.Description);
                cmd.Parameters.AddWithValue("@ImageUrl", item.ImageUrl);

                dbc.ConOpen();
                int rowsAffected = cmd.ExecuteNonQuery();
                dbc.ConClose();

                if (rowsAffected > 0)
                {
                    response.Statuscode = 200;
                    response.StatusMessage = "Item updated successfully.";
                }
                else
                {
                    response.Statuscode = 400;
                    response.StatusMessage = "Failed to update item.";
                }
            }
            catch (Exception ex)
            {
                response.Statuscode = 500;
                response.StatusMessage = $"Error: {ex.Message}";
            }

            return response;
        }

        public Response DeleteInventoryItem(int itemId, SqlConnection connection)
        {
            Response response = new Response();
            DBConnection dbc = new DBConnection();

            try
            {
                SqlCommand cmd = new SqlCommand("DELETE FROM Inventorys WHERE ItemId = @ItemId", dbc.GetConn()); 
                cmd.Parameters.AddWithValue("@ItemId", itemId);

                dbc.ConOpen();
                int rowsAffected = cmd.ExecuteNonQuery();
                dbc.ConClose();

                if (rowsAffected > 0)
                {
                    response.Statuscode = 200;
                    response.StatusMessage = "Item deleted successfully.";
                }
                else
                {
                    response.Statuscode = 400;
                    response.StatusMessage = "Failed to delete item.";
                }
            }
            catch (Exception ex)
            {
                response.Statuscode = 500;
                response.StatusMessage = $"Error: {ex.Message}";
            }

            return response;
        }


        public Response GetInventoryItem(int itemId)
        {
            Response response = new Response();
            List<Inventory> items = new List<Inventory>();

            try
            {
                using (SqlConnection connection = new DBConnection().GetConn()) 
                {
                    SqlCommand cmd = new SqlCommand("SELECT * FROM Inventorys WHERE ItemId = @ItemId", connection);
                    cmd.Parameters.AddWithValue("@ItemId", itemId);

                    connection.Open();

                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        items.Add(new Inventory
                        {
                            ItemId = Convert.ToInt32(reader["ItemId"]),
                            ItemName = reader["ItemName"].ToString(),
                            Quantity = Convert.ToInt32(reader["Quantity"]),
                            Price = Convert.ToDecimal(reader["Price"]),
                            SupplierId = Convert.ToInt32(reader["SupplierId"]),
                            SupplierName = reader["SupplierName"].ToString(),
                            Description = reader["Description"].ToString(),
                            ImageUrl = reader["ImageUrl"].ToString(),
                        });

                        response.Statuscode = 200;
                        response.StatusMessage = "Item retrieved successfully.";
                        response.List = items;
                    }
                    else
                    {
                        response.Statuscode = 404;
                        response.StatusMessage = "Item not found.";
                    }
                }
            }
            catch (Exception ex)
            {
                response.Statuscode = 500;
                response.StatusMessage = $"Error: {ex.Message}";
            }

            return response;
        }


        public Response GetInventoryBySupplier(int supplierId, SqlConnection connection)
        {
            Response response = new Response();
            List<Inventory> inventoryList = new List<Inventory>();

            try
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM Inventorys WHERE SupplierId = @SupplierId", connection);
                cmd.Parameters.AddWithValue("@SupplierId", supplierId);

                connection.Open(); 
                SqlDataReader reader = cmd.ExecuteReader(); 

                while (reader.Read()) 
                {
                    inventoryList.Add(new Inventory
                    {
                        ItemId = Convert.ToInt32(reader["ItemId"]),
                        ItemName = reader["ItemName"].ToString(),
                        Quantity = Convert.ToInt32(reader["Quantity"]),
                        Price = Convert.ToDecimal(reader["Price"]),
                        SupplierId = Convert.ToInt32(reader["SupplierId"]),
                        SupplierName = reader["SupplierName"].ToString(),
                        Description = reader["Description"].ToString(),
                        ImageUrl = reader["ImageUrl"].ToString(),
                    });

                }

                if (inventoryList.Count > 0) 
                {
                    response.Statuscode = 200;
                    response.StatusMessage = "Inventory items retrieved successfully.";
                    response.List = inventoryList;

                }
                else
                {
                    response.Statuscode = 404; 
                    response.StatusMessage = "No items found for the specified supplier.";
                }

                connection.Close();
            }
            catch (Exception ex)
            {
                response.Statuscode = 500; 
                response.StatusMessage = $"Error: {ex.Message}";
            }

            return response; 
        }

        public Response AddSupplier(Supplier supplier, SqlConnection connection)
        {
            Response response = new Response();
            DBConnection dbc = new DBConnection();

            try
            {
                SqlCommand cmd = new SqlCommand("Insert Into Suppliers(SupplierName,Email,PhoneNumber,Address, ImageUrl)Values(@SupplierName,@Email,@PhoneNumber,@Address, @ImageUrl)", dbc.GetConn());

                cmd.Parameters.AddWithValue("@SupplierName", supplier.SupplierName);
                cmd.Parameters.AddWithValue("@Email", supplier.Email);
                cmd.Parameters.AddWithValue("@PhoneNumber", supplier.PhoneNumber);
                cmd.Parameters.AddWithValue("@Address", supplier.Address);
                cmd.Parameters.AddWithValue("@ImageUrl", supplier.ImageUrl);


                dbc.ConOpen();
                int rowsAffected = cmd.ExecuteNonQuery();
                dbc.ConClose();
                if (rowsAffected > 0)
                {
                    response.Statuscode = 200;
                    response.StatusMessage = "Supplier Added Completed";
                }
                else
                {
                    response.Statuscode = 400;
                    response.StatusMessage = "Supplier Added Not Completed";
                }
            }
            catch (Exception ex)
            {
                response.Statuscode = 500;
                response.StatusMessage = $"Error: {ex.Message}";
            }

            return response;
        }

        public Response GetAllSuppliers(SqlConnection connection)
        {
            Response response = new Response();
            try
            {
                List<Supplier> suppliers = new List<Supplier>();
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM Suppliers", connection))
                {
                    connection.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            suppliers.Add(new Supplier
                            {
                                SupplierID = Convert.ToInt32(reader["SupplierID"]),
                                SupplierName = reader["SupplierName"].ToString(),
                                Email = reader["Email"].ToString(),
                                PhoneNumber = reader["PhoneNumber"].ToString(),
                                Address = reader["Address"].ToString(),
                                ImageUrl = reader["ImageUrl"].ToString()

                            });
                        }
                    }
                    connection.Close();
                }

                response.Statuscode = 200;
                response.StatusMessage = "Suppliers retrieved successfully.";
                response.Suppliers = suppliers;
            }
            catch (Exception ex)
            {
                response.Statuscode = 500;
                response.StatusMessage = $"Error: {ex.Message}";
            }
            return response;
        }

        public Response CreateQuotation(Quotation quotation, SqlConnection connection)
        {
            Response response = new Response();
            DBConnection dbc = new DBConnection();

            try
            {
                SqlCommand cmd = new SqlCommand("Insert Into Quotations (SupplierName,Items)Values(@SupplierName,@Items)", dbc.GetConn());

                cmd.Parameters.AddWithValue("@SupplierName", quotation.SupplierName);
                cmd.Parameters.AddWithValue("@Items", quotation.Items);
         
                dbc.ConOpen();
                int rowsAffected = cmd.ExecuteNonQuery();
                dbc.ConClose();
                if (rowsAffected > 0)
                {
                    response.Statuscode = 200;
                    response.StatusMessage = "Quotation Request sent Successfully";
                }
                else
                {
                    response.Statuscode = 400;
                    response.StatusMessage = "Error Creating Quotation";
                }
            }
            catch (Exception ex)
            {
                response.Statuscode = 500;
                response.StatusMessage = $"Error: {ex.Message}";
            }

            return response;
        }

        public Response ViewQuotation(SqlConnection connection)
        {
            Response response = new Response();
            DBConnection dbc = new DBConnection();

            try
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM Quotations", dbc.GetConn());
                dbc.ConOpen();
                SqlDataReader reader = cmd.ExecuteReader();

                List<Quotation> quotations = new List<Quotation>();

                while (reader.Read())
                {
                    Quotation quotation = new Quotation()
                    {
                        Id = Convert.ToInt32(reader["Id"]),
                        SupplierName = reader["SupplierName"].ToString(),
                        Items = reader["Items"].ToString(),
                    };
                    quotations.Add(quotation);
                }

                dbc.ConClose();
                response.Statuscode = 200;
                response.StatusMessage = "Orders Retrieved Successfully";
                response.Quotations = quotations;
            }
            catch (Exception ex)
            {
                response.Statuscode = 500;
                response.StatusMessage = $"Error: {ex.Message}";
            }

            return response;
        }

    }
}

