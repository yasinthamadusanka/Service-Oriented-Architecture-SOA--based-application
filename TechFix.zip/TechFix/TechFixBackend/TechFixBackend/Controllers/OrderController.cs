﻿using Microsoft.AspNetCore.Mvc;
using Techfix.Model;
using Techfix.Utili;
using TechFixBackend.Model;

namespace TechFixBackend.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OrderController : ControllerBase
    {
        private readonly Dal _dal;
        private readonly IConfiguration _configuration;

        public OrderController(IConfiguration configuration)
        {
            _configuration = configuration;
            _dal = new Dal();
        }

        [HttpGet]
        [Route("ViewOrders")]
        public IActionResult ViewOrders()
        {
            DBConnection dbc = new DBConnection();
            var response = _dal.ViewOrders(dbc.GetConn());
            if (response.Statuscode == 200)
                return Ok(response);
            else
                return StatusCode(response.Statuscode, response);
        }


        [HttpPost]
        [Route("AddOrder")]
        public IActionResult AddOrder([FromBody] Order order)
        {
            if (order == null)
            {
                return BadRequest(new Response { Statuscode = 400, StatusMessage = "Invalid Data" });
            }
            DBConnection dbc = new DBConnection();
            Response response = _dal.AddOrder(order, dbc.GetConn());
            if (response.Statuscode == 200)
            {
                return Ok(response);
            }
            else if (response.Statuscode == 400)
            {
                return BadRequest(response);
            }
            else
            {
                return StatusCode
                      (StatusCodes.Status500InternalServerError, response);

            }
        }
    }
}
