﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Techfix.Model;
using Techfix.Utili;
using TechFixBackend.Model;

namespace TechFixBackend.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class InventoryController : ControllerBase
    {
        private readonly Dal _dal;
        private readonly IConfiguration _configuration;

        public InventoryController(IConfiguration configuration)
        {
            _configuration = configuration;
            _dal = new Dal();
        }

        [HttpGet]
        [Route("ViewInventory")]
        public IActionResult ViewInventory()
        {
            DBConnection dbc = new DBConnection();
            var response = _dal.ViewInventory(dbc.GetConn());
            if (response.Statuscode == 200)
                return Ok(response);
            else
                return StatusCode(response.Statuscode, response);
        }


        [HttpGet("supplier/{supplierId}")]
        public IActionResult GetInventoryBySupplier(int supplierId)
        {
            DBConnection dbc = new DBConnection();
            var response = _dal.GetInventoryBySupplier(supplierId, dbc.GetConn());
            if (response.Statuscode == 200)
                return Ok(response);
            else
                return StatusCode(response.Statuscode, response);
        }

        [HttpGet("{id}")]
        public IActionResult GetInventoryItem(int id)
        {
            try
            {
                var response = _dal.GetInventoryItem(id);  
                if (response.Statuscode == 200)
                    return Ok(response);
                else
                    return StatusCode(response.Statuscode, response);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new Response { Statuscode = 500, StatusMessage = $"Error: {ex.Message}" });
            }
        }


        [HttpPost]
        [Route("AddInventoryItem")]
        public IActionResult AddInventoryItem([FromBody] Inventory item)
        {   
            if(item == null)
            {
                return BadRequest(new Response { Statuscode = 400, StatusMessage = "Invalid Data" });
            }
            DBConnection dbc = new DBConnection();
            Response response = _dal.AddInventoryItem(item, dbc.GetConn());
            if (response.Statuscode == 200)
            {
                return Ok(response);
            }
            else if (response.Statuscode == 400)
            {
                return BadRequest(response);
            }
            else
            {
                return StatusCode
                      (StatusCodes.Status500InternalServerError, response);

            }

        }

        [HttpPut("{id}")]
        public IActionResult UpdateInventoryItem(int id, [FromBody] Inventory updatedItem)
        {
            if (!ModelState.IsValid || updatedItem == null)
                return BadRequest("Invalid item data.");

            updatedItem.ItemId = id;
            DBConnection dbc = new DBConnection();
            var response = _dal.UpdateInventoryItem(updatedItem, dbc.GetConn());

            return StatusCode(response.Statuscode, response);
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteInventoryItem(int id)
        {
            DBConnection dbc = new DBConnection();
            var response = _dal.DeleteInventoryItem(id, dbc.GetConn());

            return StatusCode(response.Statuscode, response);
        }
    }
}
