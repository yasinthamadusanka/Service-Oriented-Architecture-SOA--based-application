﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Techfix.Model;
using Techfix.Utili;

namespace Techfix.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StaffController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private Dal _dal;

        public StaffController(IConfiguration configuration)
        {
            _configuration = configuration;
            _dal = new Dal();
        }

        [HttpPost]
        [Route("AddStaff")]

        public IActionResult AddStaff([FromBody] Staff staff)
        {

            if (staff == null)
            {
                return BadRequest(new Response { Statuscode = 400, StatusMessage = "Invalid Data" });
            }
            DBConnection dbc = new DBConnection();
            Response response = _dal.AddStaff(staff, dbc.GetConn());
            if (response.Statuscode == 200)
            {
                return Ok(response);
            }
            else if (response.Statuscode == 400)
            {
                return BadRequest(response);
            }
            else
            {
                return StatusCode
                      (StatusCodes.Status500InternalServerError, response);

            }

        }


        [HttpPost]
        [Route("StaffLogin")]

        public IActionResult StaffLogin([FromBody] StaffLogin staffLogin)
        {

            if (staffLogin == null || string.IsNullOrEmpty(staffLogin.Email) || string.IsNullOrEmpty(staffLogin.Password))
            {
                return BadRequest(new Response { Statuscode = 400, StatusMessage = "invalid Data" });

            }

            try
            {
                DBConnection dbc = new DBConnection();
                Response response = _dal.StaffLogin(staffLogin, dbc.GetConn());

                if (response.Statuscode == 200)
                {
                    return Ok(response);
                }
                else if (response.Statuscode == 401)
                {
                    return Unauthorized(response);
                }
                else
                {
                    return StatusCode(StatusCodes.Status500InternalServerError, response);
                }

            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new Response { Statuscode = 500, StatusMessage = ex.Message });


            }
        }

    }

}







