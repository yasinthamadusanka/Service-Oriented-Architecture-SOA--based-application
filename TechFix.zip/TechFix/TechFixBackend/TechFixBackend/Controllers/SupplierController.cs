﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Techfix.Model;
using Techfix.Utili;

namespace Techfix.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SupplierController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private Dal _dal;

        public SupplierController(IConfiguration configuration)
        {
            _configuration = configuration;
            _dal = new Dal();
        }

        // Endpoint to add a supplier
        [HttpPost]
        [Route("AddSupplier")]
        public IActionResult AddSupplier([FromBody] Supplier supplier)
        {
            if (supplier == null)
            {
                return BadRequest(new Response { Statuscode = 400, StatusMessage = "Invalid Data" });
            }

            DBConnection dbc = new DBConnection();
            Response response = _dal.AddSupplier(supplier, dbc.GetConn());

            if (response.Statuscode == 200)
            {
                return Ok(response);
            }
            else if (response.Statuscode == 400)
            {
                return BadRequest(response);
            }
            else
            {
                return StatusCode(StatusCodes.Status500InternalServerError, response);
            }
        }

        [HttpGet]
        [Route("GetAllSuppliers")]
        public IActionResult GetAllSuppliers()
        {
            DBConnection dbc = new DBConnection();
            var response = _dal.GetAllSuppliers(dbc.GetConn());
            if (response.Statuscode == 200)
                return Ok(response);
            else
                return StatusCode(response.Statuscode, response);
        }
    }
}
