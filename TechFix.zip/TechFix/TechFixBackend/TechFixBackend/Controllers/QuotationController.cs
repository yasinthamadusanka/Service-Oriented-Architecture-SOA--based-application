﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Techfix.Model;
using Techfix.Utili;

namespace Techfix.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class QuotationController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private Dal _dal;

        public QuotationController(IConfiguration configuration)
        {
            _configuration = configuration;
            _dal = new Dal();
        }

        [HttpGet]
        [Route("ViewQuotation")]
        public IActionResult ViewQuotation()
        {
            DBConnection dbc = new DBConnection();
            var response = _dal.ViewQuotation(dbc.GetConn());
            if (response.Statuscode == 200)
                return Ok(response);
            else
                return StatusCode(response.Statuscode, response);
        }

        [HttpPost]
        [Route("CreateQuotation")]

        public IActionResult CreateQuotation([FromBody] Quotation quotation)
        {

            if (quotation == null)
            {
                return BadRequest(new Response { Statuscode = 400, StatusMessage = "Invalid Data" });
            }
            DBConnection dbc = new DBConnection();
            Response response = _dal.CreateQuotation(quotation, dbc.GetConn());
            if (response.Statuscode == 200)
            {
                return Ok(response);
            }
            else if (response.Statuscode == 400)
            {
                return BadRequest(response);
            }
            else
            {
                return StatusCode(StatusCodes.Status500InternalServerError, response);

            }

        }
    }

}

