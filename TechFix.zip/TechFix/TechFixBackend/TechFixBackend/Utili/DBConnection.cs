﻿using Microsoft.Data.SqlClient;

namespace Techfix.Utili
{
    public class DBConnection
    {
        private SqlConnection connection;
        public DBConnection()
        {
            var constring = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build().GetConnectionString("DefaultConnection");
            connection = new SqlConnection(constring);
        }
        public SqlConnection GetConn()
        {
            return connection;
        }
        public void ConOpen()
        {
            connection.Open();
        }
        public void ConClose()
        {
            if (connection.State == System.Data.ConnectionState.Open)
            {
                connection.Close();
            }
        }
    }
}

